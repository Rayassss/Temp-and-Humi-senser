#ifndef _GUI_H_
#define _GUI_H_
void Draw_DHT11();
void Draw_DS1302();
#endif