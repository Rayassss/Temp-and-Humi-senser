#ifndef _DHT11_H_
#define _DHT11_H_
void Readbyte();
void DHT11_init();
void SendData(unsigned char *a);
void go_DHT11();
void Transvalue();
#endif
