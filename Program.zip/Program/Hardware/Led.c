#include "STC8F.h"
#include "Led.h"
void Ledinit()
{
	Led = 0;
}