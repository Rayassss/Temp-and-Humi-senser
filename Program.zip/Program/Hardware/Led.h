#ifndef _LED_H_
#define _LED_H_
sbit Led = P2^2;
void Ledinit();

#endif
