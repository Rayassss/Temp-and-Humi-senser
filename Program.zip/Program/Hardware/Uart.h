#ifndef _UART_H_
#define _UART_H_
void Send_string(unsigned char *a);
void Uart1_Init();
#endif
