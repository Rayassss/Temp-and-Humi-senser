#ifndef _DELAY_H_
#define _DELAY_H_
void Delayms(unsigned int xms);
void Delay30us();
void Delay80us();
void Delay1us();
void Delay40us();
void Delay50us();
void Delay20ms();
void Delay18ms();
void Delay2000ms();
void Delay100us();
void Delay100ms()	;
void Delay1000ms();

#endif
